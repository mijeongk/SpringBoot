package kr.kdata.pds;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MybatisEx05PdsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MybatisEx05PdsApplication.class, args);
	}

}
