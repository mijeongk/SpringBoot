SELECT * FROM board ORDER BY id DESC;

INSERT INTO bcomment
VALUES (comment_id_seq.nextval, 7435, '지나는이','1234','와 일빠다',sysdate);

INSERT INTO bcomment
VALUES (comment_id_seq.nextval, 7435, '지나는이','1234','와 이빠다',sysdate);

INSERT INTO bcomment
VALUES (comment_id_seq.nextval, 7432, '지나는이','1234','와 일빠다',sysdate);

INSERT INTO bcomment
VALUES (comment_id_seq.nextval, 7432, '지나는이','1234','와 이빠다',sysdate);

INSERT INTO bcomment
VALUES (comment_id_seq.nextval, 7432, '지나는이','1234','와 삼빠다',sysdate);