package kr.kdata.board;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MybatisEx04FreeBoardApplication {

	public static void main(String[] args) {
		SpringApplication.run(MybatisEx04FreeBoardApplication.class, args);
	}

}
