package kr.kdata.board.dao;

public interface TestDAO {

}
