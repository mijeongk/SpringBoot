package kr.top2blue.board;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaFreeBoardApplicationTests {

	@Test
	void contextLoads() {
	}

}
